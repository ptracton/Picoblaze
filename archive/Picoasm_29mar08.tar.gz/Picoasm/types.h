

typedef unsigned char 	uint8_t ;
typedef unsigned short 	uint16_t ;
typedef unsigned int 	uint32_t ;

#define TRUE	1
#define FALSE	0

